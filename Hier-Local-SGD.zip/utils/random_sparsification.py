# Will compress each layer of the model respectively
# The first argument should be nn.model class
import torch
from options import args_parser

def randomk_nn(model, compression_ratio):
    param = list(model.nn_layers.parameters())
    nc = len(param)
    for i in range(nc):
        param_shape = param[i].shape
        param[i].data = torch.flatten(param[i])
        if torch.cuda.is_available():
            mask = (1 / compression_ratio) * torch.ones(param[i].shape).cuda()
            indices = torch.randperm(mask.shape[0]).cuda()
        else:
            mask = (1 / compression_ratio) * torch.ones(param[i].shape)
            indices = torch.randperm(mask.shape[0])
        indices = indices[:int(indices.shape[0] * (1 - compression_ratio))]
        mask[indices] = 0
        param[i].data = torch.mul(param[i].data, mask)
        # param[i].data *= mask
        param[i].data = torch.reshape(param[i].data, param_shape)
    return model

def randomk_nne(model, compression_ratio):
    param = list(model.parameters())
    nc = len(param)
    for i in range(nc):
        param_shape = param[i].shape
        param[i].data = torch.flatten(param[i])
        if torch.cuda.is_available():
            mask = (1 / compression_ratio) * torch.ones(param[i].shape).cuda()
            indices = torch.randperm(mask.shape[0]).cuda()
        else:
            mask = (1 / compression_ratio) * torch.ones(param[i].shape)
            indices = torch.randperm(mask.shape[0])
        indices = indices[:int(indices.shape[0] * (1-compression_ratio))]
        mask[indices] = 0
        param[i].data = torch.mul(param[i].data, mask)
        # param[i].data *= mask
        param[i].data = torch.reshape(param[i].data, param_shape)
    return None

