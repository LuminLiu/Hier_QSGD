import numpy as np
import torch

"""
Quantization scheme for QSGD
Follows Alistarh, 2017 (https://arxiv.org/abs/1610.02132) but without the compression scheme.
"""

# need to check this function
def quantize(x, d):
    """quantize the tensor x in d level on the absolute value coef wise"""
    norm = np.sqrt(np.sum(np.square(x)))
    level_float = d * np.abs(x) / norm
    previous_level = np.floor(level_float)
    is_next_level = np.random.rand(*x.shape) < (level_float - previous_level)
    new_level = previous_level + is_next_level
    return np.sign(x) * norm * new_level / d

def sr_nn(model, compression_ratio):
    param = list(model.nn_layers.parameters())
    nc = len(param)
    # here we need a computation between the q and d
    d = 32
    for i in range(nc):
        param_shape = param[i].shape
        param[i].data = torch.flatten(param[i])
        param[i].data = quantize(param[i].data, d)
        param[i].data = torch.reshape(param[i].data, param_shape)
    return model

def sr_nne(model, compression_ratio):
    param = list(model.parameters())
    nc = len(param)
    # here we need a computation between the q and d
    d = 32
    for i in range(nc):
        param_shape = param[i].shape
        param[i].data = torch.flatten(param[i])
        param[i].data = quantize(param[i].data, d)
        param[i].data = torch.reshape(param[i].data, param_shape)
    return None